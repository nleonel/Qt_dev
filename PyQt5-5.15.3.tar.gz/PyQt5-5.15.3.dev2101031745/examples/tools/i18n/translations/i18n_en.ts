<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>E&amp;xit</source>
        <translation>E&amp;xit</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Internationalization Example</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Language: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <source>View</source>
        <translation>View</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspective</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometric</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblique</translation>
    </message>
    <message>
        <source>First</source>
        <translation>First</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Second</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Third</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
